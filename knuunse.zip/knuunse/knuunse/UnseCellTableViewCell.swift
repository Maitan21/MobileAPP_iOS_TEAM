//
//  UnseCellTableViewCell.swift
//  knuunse
//
//  Created by  ZAEONE on 2020/05/24.
//  Copyright © 2020 COMP420. All rights reserved.
//

import UIKit

class UnseCellTableViewCell: UITableViewCell {

    @IBOutlet weak var ZodiacImageView: UIImageView!
    @IBOutlet weak var ZodiacName: UILabel!
    @IBOutlet weak var UnseString: UILabel!
    

}
